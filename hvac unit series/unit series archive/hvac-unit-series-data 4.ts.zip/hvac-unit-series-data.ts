const MODEL_ID = '017645db0453454b8f5f6ff753822eb9';


interface Media {
    media: string;
  }
  
  interface WarrantyDocument {
    document: string;
  }
  
  interface WarrantyOption {
    transferable: boolean;
    type: string;
    documents: WarrantyDocument[];
    durationYears: number;
  }
  
  interface SmartFeatures {
    energyTracking: boolean;
    voiceControl: boolean;
    appControl: boolean;
    homeAutomationIntegration: boolean;
  }
  
  /* interface Size {
    heatingKw: number;
    sizeKw: number;
    name: {
      "@type": string;
      id: string;
      model: string;
    };
  } */
  
  interface KeyFeature {
    icon:string;
    summary: string;
    heading: string;
  }
  
  interface HVACUnitSeriesData {
    seriesCode: string;
    unitConfig:
      | 'High Wall Split System'
      | 'Ducted'
      | 'Portable'
      | 'Cassette'
      | 'Multi-Split System'
      | 'Window Air Conditioner'
      | 'Floor Mounted'
      | 'Ceiling Mounted Ductless'
      | 'Ceiling Suspended';
    smartFeatures: SmartFeatures;
    brand: 'Mitsubishi';
    keyFeatures: KeyFeature[];
    productMedia: Media[];
    name: string /* Designer Series */;
    thumbnailImage: string;
    warrantyOptions: WarrantyOption[];
    description: string;
    /* relatedAccessories: string;*/
    /* servicePlans: string; */
    /* installationRequirements: string; */
    /*  installationOptions: string; */
    /* sizes: Size[]; */
  }
  
  interface HVACUnitSeries {
    name: string;
    modelId: string;
    data: HVACUnitSeriesData;
  }
  
  // Define multiple HVAC products
  export const items: HVACUnitSeries[] = [
    {
      name: "GS Series",
      modelId: MODEL_ID,
      data: {
        seriesCode: "GS",
        unitConfig: "High Wall Split System",
        smartFeatures: {
          energyTracking: true,
          voiceControl: true,
          appControl: true,
          homeAutomationIntegration: true
        },
        brand: "Mitsubishi",
        keyFeatures: [
          {
            heading: "Energy-Saving R32 Technology",
            summary: "Save on your power bills with advanced R32 technology that delivers superior energy efficiency. This next-generation system uses less power to keep your home comfortable all year round."
          },
          {
            heading: "Built to Last in Coastal Areas",
            summary: "Perfect for New Zealand homes near the coast, the Blue Fin protection keeps your heat pump running efficiently for longer by protecting it from salt air and environmental wear."
          },
          {
            heading: "Breathe Cleaner Air",
            summary: "Keep your family healthy with advanced air filtration that removes dust, pollen, and other allergens. The optional Anti-Allergy filter takes comfort further by targeting bacteria, mold, and dust mites."
          },
          {
            heading: "Smart Energy Saving Mode",
            summary: "Econo Cool automatically adjusts airflow to create a cooling breeze effect, helping you stay comfortable while using less energy - perfect for those warm summer days."
          },
          {
            heading: "Even Room Temperature",
            summary: "Say goodbye to hot and cold spots. The Vertical Swing feature ensures every corner of your room stays comfortable by distributing air evenly throughout the space."
          },
          {
            heading: "Simple Temperature Control",
            summary: "The easy-to-use controller puts comfort at your fingertips with large, clear buttons and a simple display. Perfect for everyone in the family, from kids to grandparents."
          },
          {
            heading: "7-Day Timer for Smart Comfort",
            summary: "Program your perfect temperature schedule for each day of the week. Wake up to a warm home in winter or come home to refreshing cooling in summer - all while maximizing energy savings."
          },
          {
            heading: "Control from Anywhere",
            summary: "Add optional Wi-Fi control to adjust your home's temperature from your phone, whether you're at work, running late, or on vacation. Always arrive home to perfect comfort."
          },
          {
            heading: "Advanced Air Purification Option",
            summary: "For families concerned about air quality, the optional Plasma Quad Connect provides hospital-grade air filtration, creating a healthier home environment all year round."
          },
          {
            heading: "Extra Protection for Coastal Homes",
            summary: "For homes in coastal areas, the optional Corrosion Protection Service extends your heat pump's life and maintains its efficiency in challenging environments."
          }
        ],
        productMedia: [
          {
            media: "https://mitsubishi-electric.co.nz/heatpump/i/69334B/standard-gs-25-high-wall-heat-pump/image1.jpg"
          },
          {
            media: "https://mitsubishi-electric.co.nz/heatpump/i/69334B/standard-gs-25-high-wall-heat-pump/image2.jpg"
          }
        ],
        name: "GS Series",
        thumbnailImage: "https://mitsubishi-electric.co.nz/heatpump/i/69334B/standard-gs-25-high-wall-heat-pump/thumbnail.jpg",
        warrantyOptions: [
          {
            transferable: true,
            type: "Full Coverage",
            documents: [
              {
                document: "https://mitsubishi-electric.co.nz/heatpump/i/69334B/standard-gs-25-high-wall-heat-pump/warranty.pdf"
              }
            ],
            durationYears: 5
          }
        ],
        description: "The GS Series delivers exceptional value with efficient heating and cooling that's perfect for New Zealand homes. Built with superior Japanese technology, this heat pump combines affordable comfort with reliable performance in all seasons. Its user-friendly features and energy-efficient operation make it an ideal choice for families wanting quality climate control without compromising on running costs."
      }
    },
    {
      name: "AP Mini Series",
      modelId: MODEL_ID,
      data: {
        seriesCode: "AP",
        unitConfig: "High Wall Split System",
        smartFeatures: {
          energyTracking: true,
          voiceControl: true,
          appControl: true,
          homeAutomationIntegration: true
        },
        brand: "Mitsubishi",
        keyFeatures: [
          {
            heading: "Perfect Night's Sleep",
            summary: "Sleep soundly with Night Mode, which dims the display light, silences any beeping, and reduces outdoor noise by 3dBA. Your family and neighbors will appreciate the extra quiet operation during bedtime."
          },
          {
            heading: "No More Cold Drafts",
            summary: "Stay cozy without feeling cold air blowing directly on you. The horizontal airflow system gently spreads cool air across the ceiling first, creating an even, comfortable environment throughout the room."
          },
          {
            heading: "Smart Energy Savings",
            summary: "Save money on your power bills with Econo Cool, which cleverly adjusts airflow patterns to make the room feel cooler while using less energy - perfect for managing summer cooling costs."
          },
          {
            heading: "Memory Settings for Easy Control",
            summary: "The i-Save Mode remembers your favorite temperature and fan settings, including an energy-saving 10°C setting for when rooms are empty. One button press returns your room to your ideal comfort level."
          },
          {
            heading: "Built for Coastal Living",
            summary: "Perfect for New Zealand's coastal homes, the Blue Fin coating protects your heat pump from salt air and environmental wear, helping it run efficiently for years to come."
          },
          {
            heading: "Weekly Timer for Smart Comfort",
            summary: "Program up to four temperature changes each day of the week. Wake up warm, come home to comfort, and save energy while you're away - all automatically."
          },
          {
            heading: "Control from Anywhere",
            summary: "Add optional Wi-Fi control to manage your home's temperature from your phone. Running late? Coming home early? Adjust your heat pump from anywhere so you always arrive to perfect comfort."
          },
          {
            heading: "Healthier Air for Your Family",
            summary: "Breathe easier with the optional Plasma Quad Connect air filtration system. It removes dust, allergens, and other particles, creating cleaner, healthier air throughout your home all year round."
          }
        ],
        productMedia: [
          {
            media: "https://mitsubishi-electric.co.nz/heatpump/i/69325B/classic-ap-20-high-wall-heat-pump/image1.jpg"
          },
          {
            media: "https://mitsubishi-electric.co.nz/heatpump/i/69325B/classic-ap-20-high-wall-heat-pump/image2.jpg"
          }
        ],
        name: "AP Mini Series",
        thumbnailImage: "https://mitsubishi-electric.co.nz/heatpump/i/69325B/classic-ap-20-high-wall-heat-pump/thumbnail.jpg",
        warrantyOptions: [
          {
            transferable: true,
            type: "Full Coverage",
            documents: [
              {
                document: "https://mitsubishi-electric.co.nz/heatpump/i/69325B/classic-ap-20-high-wall-heat-pump/warranty.pdf"
              }
            ],
            durationYears: 5
          }
        ],
        description: "The AP Mini Series is New Zealand's smallest high wall heat pump, making it perfect for bedrooms and compact spaces. Despite its small size, it delivers powerful performance and smart features that keep your room comfortable while saving energy. Its whisper-quiet operation, advanced filtration options, and user-friendly controls make it an ideal choice for creating comfortable, healthy spaces in any home."
      }
    },
    {
      name: "AP Classic Series",
      modelId: MODEL_ID,
      data: {
        seriesCode: "AP",
        unitConfig: "High Wall Split System",
        smartFeatures: {
          energyTracking: true,
          voiceControl: true,
          appControl: true,
          homeAutomationIntegration: true
        },
        brand: "Mitsubishi",
        keyFeatures: [
          {
            heading: "Whisper-Quiet Operation",
            summary: "Experience New Zealand's quietest heat pump, running at just 18 dBA - quieter than a whisper. Perfect for light sleepers, the AP25 model with Night Mode is so quiet you'll forget it's there, even in bedrooms on the coldest winter nights."
          },
          {
            heading: "Self-Cleaning Technology",
            summary: "The innovative Dual Barrier Coating keeps your heat pump clean and efficient year-round. This special coating prevents dust and dirt from sticking to internal parts, meaning consistent performance, no unpleasant odors, and lower running costs."
          },
          {
            heading: "Energy-Efficient Cooling and Heating",
            summary: "Save on power bills with next-generation R32 technology. This advanced refrigerant is more environmentally friendly and energy-efficient than older systems, helping you stay comfortable for less."
          },
          {
            heading: "Better Air Quality",
            summary: "Breathe cleaner, fresher air with the washable Air Purifying Filter. This advanced filter captures dust, pollen, and other airborne particles, while neutralizing odors - perfect for allergy sufferers and families concerned about indoor air quality."
          },
          {
            heading: "Draft-Free Comfort",
            summary: "Stay comfortable without feeling cold air blowing directly on you. The horizontal airflow system spreads air evenly across the ceiling first, creating consistent comfort throughout your room."
          },
          {
            heading: "Built for Coastal Homes",
            summary: "The Blue Fin coating protects your heat pump from salt air and coastal conditions, making it ideal for New Zealand's coastal homes. This special treatment helps maintain efficiency and extends the life of your investment."
          },
          {
            heading: "Perfect Night's Sleep",
            summary: "Night Mode ensures peaceful sleep by dimming display lights, silencing beeps, and reducing outdoor unit noise. Both you and your neighbors will appreciate the extra quiet operation."
          },
          {
            heading: "Smart Home Control",
            summary: "Add optional Wi-Fi Control to manage your heat pump from anywhere using your smartphone. Adjust settings, monitor usage, and ensure your home is always at the perfect temperature when you arrive."
          },
          {
            heading: "Hospital-Grade Air Filtration Option",
            summary: "For ultimate air quality, add the optional Plasma Quad Connect. This advanced filtration system removes microscopic particles, allergens, and bacteria, bringing hospital-grade air purification to your home."
          }
        ],
        productMedia: [
          {
            media: "https://mitsubishi-electric.co.nz/heatpump/i/69407B/classic-ap-25-high-wall-heat-pump/image1.jpg"
          },
          {
            media: "https://mitsubishi-electric.co.nz/heatpump/i/69407B/classic-ap-25-high-wall-heat-pump/image2.jpg"
          }
        ],
        name: "AP Classic Series",
        thumbnailImage: "https://mitsubishi-electric.co.nz/heatpump/i/69407B/classic-ap-25-high-wall-heat-pump/thumbnail.jpg",
        warrantyOptions: [
          {
            transferable: true,
            type: "Full Coverage",
            documents: [
              {
                document: "https://mitsubishi-electric.co.nz/heatpump/i/69407B/classic-ap-25-high-wall-heat-pump/warranty.pdf"
              }
            ],
            durationYears: 5
          }
        ],
        description: "The AP Classic Series sets a new standard in super-efficient, whisper-quiet heating and cooling. Starting at just 18dBA, it's New Zealand's quietest heat pump - perfect for bedrooms and living spaces where peace and quiet matter most. With advanced features like self-cleaning technology and optional Wi-Fi control, it delivers year-round comfort while keeping running costs low. Its superior air filtration and draft-free operation make it an ideal choice for families wanting the perfect balance of comfort, efficiency, and clean, healthy air."
      }
    },
    {
      name: "AP Plus Series",
      modelId: MODEL_ID,
      data: {
        seriesCode: "AP",
        unitConfig: "High Wall Split System",
        smartFeatures: {
          energyTracking: true,
          voiceControl: true,
          appControl: true,
          homeAutomationIntegration: true
        },
        brand: "Mitsubishi",
        keyFeatures: [
          {
            heading: "Whisper-Quiet Comfort",
            summary: "Experience New Zealand's quietest heat pump at just 18dBA - perfect for light sleepers and peaceful living spaces. It's so quiet, you might forget it's there, even on the coldest winter nights."
          },
          {
            heading: "Advanced Quiet Technology",
            summary: "Enjoy whisper-quiet operation thanks to clever engineering: a thinner heat exchanger and larger fan working together to move air more efficiently. This means maximum comfort with minimal noise."
          },
          {
            heading: "Smart Energy Tracking",
            summary: "Take control of your power bills with built-in energy monitoring. See exactly how much energy you're using and what it costs - right from your smartphone. A simple 1°C adjustment can save up to 10% on your energy use."
          },
          {
            heading: "Control from Anywhere",
            summary: "Never come home to a cold house again. Built-in Wi-Fi lets you warm up or cool down your home from anywhere using your smartphone. Perfect for unexpected schedule changes or preparing your home for your return."
          },
          {
            heading: "Self-Cleaning Technology",
            summary: "The unique Dual Barrier Coating keeps your heat pump clean and efficient year-round. It prevents dust and dirt build-up inside the unit, maintaining peak performance and eliminating unwanted odors while reducing running costs."
          },
          {
            heading: "Energy-Efficient Performance",
            summary: "Save on power bills with next-generation R32 technology. This advanced system delivers superior heating and cooling while using less energy, helping you stay comfortable for less."
          },
          {
            heading: "Cleaner, Healthier Air",
            summary: "Breathe easier with the washable Air Purifying Filter that captures dust, pollen, and other airborne particles. Perfect for allergy sufferers and families wanting cleaner indoor air."
          },
          {
            heading: "Even Temperature Distribution",
            summary: "The Wide and Long Airflow modes ensure every corner of your room stays comfortable. Perfect for open-plan spaces, these features let you direct air exactly where you need it."
          },
          {
            heading: "Peaceful Night Mode",
            summary: "Sleep soundly with Night Mode, which dims the lights, silences beeps, and reduces outdoor unit noise by 3dBA. Both you and your neighbors will enjoy peaceful nights."
          },
          {
            heading: "Draft-Free Comfort",
            summary: "Stay cozy without feeling cold air blowing directly on you. The horizontal airflow system spreads air evenly across the ceiling first, creating consistent comfort throughout your room."
          },
          {
            heading: "Smart Energy Saving",
            summary: "The Econo Cool function intelligently adjusts airflow to make the room feel cooler while using less energy - perfect for managing summer cooling costs."
          },
          {
            heading: "Convenient Memory Settings",
            summary: "The i-Save Mode remembers your preferred temperature and fan settings, including an energy-saving 10°C setting for unoccupied rooms. One button press returns your room to perfect comfort."
          },
          {
            heading: "Built for New Zealand Conditions",
            summary: "The Blue Fin coating protects your heat pump from coastal air and environmental wear, making it perfect for New Zealand homes near the sea."
          },
          {
            heading: "Weekly Programming",
            summary: "Set up to four temperature changes each day of the week. Wake up warm, come home to comfort, and save energy while you're away - all automatically."
          },
          {
            heading: "Optional Hospital-Grade Air Filtration",
            summary: "Add the Plasma Quad Connect for ultimate air quality. This advanced system removes microscopic particles, allergens, and bacteria - bringing hospital-grade air purification to your home."
          }
        ],
        productMedia: [
          {
            media: "https://mitsubishi-electric.co.nz/heatpump/i/69400B/ecocore-ap-25-high-wall-heat-pump/image1.jpg"
          },
          {
            media: "https://mitsubishi-electric.co.nz/heatpump/i/69400B/ecocore-ap-25-high-wall-heat-pump/image2.jpg"
          }
        ],
        name: "AP Plus Series",
        thumbnailImage: "https://mitsubishi-electric.co.nz/heatpump/i/69400B/ecocore-ap-25-high-wall-heat-pump/thumbnail.jpg",
        warrantyOptions: [
          {
            transferable: true,
            type: "Full Coverage",
            documents: [
              {
                document: "https://mitsubishi-electric.co.nz/heatpump/i/69400B/ecocore-ap-25-high-wall-heat-pump/warranty.pdf"
              }
            ],
            durationYears: 5
          }
        ],
        description: "The AP Plus Series combines New Zealand's quietest heat pump technology with smart energy monitoring, making it the perfect choice for comfort-conscious homeowners. Starting at just 18dBA, it's whisper-quiet while delivering efficient heating and cooling throughout the year. With built-in Wi-Fi Energy Monitoring, homeowners can track and optimize their energy usage right from their smartphone. Its advanced features, including self-cleaning technology and superior air filtration, create the perfect balance of comfort, efficiency, and healthy air quality. Ideal for bedrooms and living spaces where both quietness and smart control matter most."
      }
    },
    {
      name: "EF Series",
      modelId: MODEL_ID,
      data: {
        seriesCode: "EF",
        unitConfig: "High Wall Split System",
        smartFeatures: {
          energyTracking: true,
          voiceControl: true,
          appControl: true,
          homeAutomationIntegration: true
        },
        brand: "Mitsubishi",
        keyFeatures: [
          {
            heading: "Track Your Energy Use",
            summary: "Take control of your power bills with built-in energy monitoring. See exactly how much energy you're using and what it costs through your smartphone or tablet. Make smarter decisions about your heating and cooling to save money all year round."
          },
          {
            heading: "Built-In Wi-Fi Control",
            summary: "Control your comfort from anywhere with seamless Wi-Fi connectivity. Hidden neatly inside the unit, this feature lets you adjust your heat pump settings from your phone whether you're at work, in bed, or away on holiday."
          },
          {
            heading: "Energy-Efficient Operation",
            summary: "Save money while helping the environment with advanced R32 technology. This next-generation system uses less energy to keep you comfortable and has a smaller environmental impact than traditional heat pumps."
          },
          {
            heading: "Whisper-Quiet Performance",
            summary: "Enjoy peaceful days and nights with super-quiet operation from just 19dBA. That's quieter than a whisper, making it perfect for bedrooms, living rooms, and home offices where peace and quiet matter most."
          },
          {
            heading: "Built for Coastal Living",
            summary: "Perfect for New Zealand's coastal homes, the Blue Fin treatment protects your heat pump from salt air and coastal conditions. This special coating helps maintain efficiency and extends the life of your investment."
          },
          {
            heading: "Advanced Air Filtration",
            summary: "Breathe cleaner, fresher air with the Nano Platinum Filter. This extra-large, washable filter removes dust, pollen, and bacteria more effectively than standard filters, helping create a healthier home environment for your family."
          },
          {
            heading: "Award-Winning Design",
            summary: "The EF Designer Series brings style to your home with its sleek, contemporary look. Available in Rich Black Diamond, Matte Silver, or Pure White, it's designed to complement any interior while delivering superior comfort."
          }
        ],
        productMedia: [
          {
            media: "https://mitsubishi-electric.co.nz/heatpump/i/69500B/designer-ef25-high-wall-pure-white/image1.jpg"
          },
          {
            media: "https://mitsubishi-electric.co.nz/heatpump/i/69500B/designer-ef25-high-wall-pure-white/image2.jpg"
          }
        ],
        name: "EF Series",
        thumbnailImage: "https://mitsubishi-electric.co.nz/heatpump/i/69500B/designer-ef25-high-wall-pure-white/thumbnail.jpg",
        warrantyOptions: [
          {
            transferable: true,
            type: "Full Coverage",
            documents: [
              {
                document: "https://mitsubishi-electric.co.nz/heatpump/i/69500B/designer-ef25-high-wall-pure-white/warranty.pdf"
              }
            ],
            durationYears: 5
          }
        ],
        description: "The EcoCore Designer Series combines stunning aesthetics with smart technology to create the perfect balance of style and substance. Available in three designer colors, this heat pump delivers exceptional energy efficiency with the convenience of built-in Wi-Fi Energy Monitoring. Its elegant, slim-line design has won prestigious awards, while its advanced features ensure optimal comfort and energy savings. Perfect for style-conscious homeowners who want both beautiful design and smart functionality in their heating and cooling solution."
      }
    },
    {
      name: "AS Series",
      modelId: MODEL_ID,
      data: {
        seriesCode: "AS",
        unitConfig: "High Wall Split System",
        smartFeatures: {
          energyTracking: true,
          voiceControl: true,
          appControl: true,
          homeAutomationIntegration: true
        },
        brand: "Mitsubishi",
        keyFeatures: [
          {
            heading: "Energy-Smart Technology",
            summary: "Save on your power bills with next-generation R32 technology. This environmentally friendly system delivers efficient heating and cooling while using less energy than traditional heat pumps, helping you stay comfortable for less."
          },
          {
            heading: "Powerful Quick-Heat Mode",
            summary: "Get warm faster with Powerful Mode. One touch automatically adjusts fan speed and temperature to reach your desired comfort level within 15 minutes - perfect for those cold winter mornings or when you've just arrived home."
          },
          {
            heading: "Even Room Temperature",
            summary: "Enjoy consistent comfort in every corner with Wide & Long Airflow. This smart feature ensures warm or cool air reaches throughout your entire room, eliminating hot and cold spots."
          },
          {
            heading: "Built for Coastal Living",
            summary: "Perfect for New Zealand's coastal homes, the Blue Fin coating protects your heat pump from salt air and coastal conditions. This special treatment helps maintain efficiency and extends the life of your investment."
          },
          {
            heading: "Advanced Air Filtration",
            summary: "Breathe healthier air with two-stage filtration. The washable filter system captures dust, pollen, and allergens, making it ideal for families with allergies or anyone wanting cleaner indoor air."
          },
          {
            heading: "Smart Energy Saving",
            summary: "Save money with i-save Mode, which remembers your preferred settings and includes a 10°C energy-saving option for unoccupied rooms. One button press returns your room to perfect comfort when you need it."
          },
          {
            heading: "Summer Energy Efficiency",
            summary: "Stay cool for less with Econo Cool, which cleverly adjusts airflow patterns to make the room feel cooler while using less energy - perfect for managing summer cooling costs."
          },
          {
            heading: "Peaceful Night Operation",
            summary: "Sleep soundly with Night Mode, which dims the operation light, silences beeping sounds, and reduces outdoor unit noise. Both you and your neighbors will appreciate the quiet operation."
          },
          {
            heading: "7-Day Programming",
            summary: "Set your perfect weekly schedule with up to four temperature changes per day. Wake up warm, come home to comfort, and save energy while you're away - all automatically."
          },
          {
            heading: "Optional Wi-Fi Control",
            summary: "Add Wi-Fi Control to manage your heat pump from anywhere using your smartphone. Adjust settings on the go, monitor usage, and ensure your home is always at the perfect temperature when you arrive."
          },
          {
            heading: "Hospital-Grade Air Filtration Option",
            summary: "For ultimate air quality, add the optional Plasma Quad Connect. This advanced system removes microscopic particles, allergens, and bacteria, bringing hospital-grade air purification to your home."
          }
        ],
        productMedia: [
          {
            media: "https://mitsubishi-electric.co.nz/heatpump/i/69333B/large-capacity-as90-high-wall-ecocore-heat-pump/image1.jpg"
          },
          {
            media: "https://mitsubishi-electric.co.nz/heatpump/i/69333B/large-capacity-as90-high-wall-ecocore-heat-pump/image2.jpg"
          }
        ],
        name: "AS Series",
        thumbnailImage: "https://mitsubishi-electric.co.nz/heatpump/i/69333B/large-capacity-as90-high-wall-ecocore-heat-pump/thumbnail.jpg",
        warrantyOptions: [
          {
            transferable: true,
            type: "Full Coverage",
            documents: [
              {
                document: "https://mitsubishi-electric.co.nz/heatpump/i/69333B/large-capacity-as90-high-wall-ecocore-heat-pump/warranty.pdf"
              }
            ],
            durationYears: 5
          }
        ],
        description: "The AS Series delivers powerful performance in an elegant package, making it perfect for larger spaces like open-plan living areas, schools, and shared spaces. With its combination of energy-efficient operation and advanced comfort features, it provides consistent heating and cooling while keeping running costs low. The unit's smart features, including optional Wi-Fi control and advanced filtration, create a comfortable and healthy environment that's easy to manage. Its robust design and protective features make it especially suitable for New Zealand's varied climate conditions."
      }
    },
    {
      name: "PKA Series",
      modelId: MODEL_ID,
      data: {
        seriesCode: "PKA",
        unitConfig: "High Wall Split System",
        smartFeatures: {
          energyTracking: true,
          voiceControl: true,
          appControl: true,
          homeAutomationIntegration: true
        },
        brand: "Mitsubishi",
        keyFeatures: [
          {
            heading: "Easy Maintenance Design",
            summary: "Keep your unit running at its best with the Quick Clean Grille feature. The intake grille slides out smoothly for simple cleaning with just water - no special tools or complicated maintenance required."
          },
          {
            heading: "Energy-Efficient Technology",
            summary: "Save on running costs while helping the environment with advanced R32 technology. This next-generation system uses less energy and has a smaller environmental impact than traditional systems, helping you stay comfortable sustainably."
          },
          {
            heading: "Sleek, Professional Look",
            summary: "The Auto-Vane Shutter automatically closes when not in use, creating a clean, modern appearance that suits any professional space. Perfect for environments where aesthetics matter."
          },
          {
            heading: "Flexible Control Options",
            summary: "Choose the control system that works best for your space. From the advanced weekly programming of the Deluxe PAR Controller to simple wired remote options, you can customize how you manage your comfort."
          },
          {
            heading: "Perfect for Technical Spaces",
            summary: "Specially designed for areas with sensitive equipment, this unit excels in server rooms and laboratories. Its precise temperature control and efficient cooling protect your valuable equipment while keeping energy costs down."
          },
          {
            heading: "Versatile Installation",
            summary: "The optional drain pump allows installation almost anywhere, with drainage possible up to 800mm above the unit. This flexibility makes it easy to place the unit exactly where you need it, even without direct outdoor access."
          },
          {
            heading: "Advanced Air Filtration",
            summary: "Create a healthier indoor environment with the optional Plasma Quad Connect. This hospital-grade filtration system removes dust, allergens, and other particles, ensuring clean, fresh air throughout your space all year round."
          }
        ],
        productMedia: [
          {
            media: "https://mitsubishi-electric.co.nz/heatpump/i/69227B/light-commercial-pka71-high-wall-heat-pump/image1.jpg"
          },
          {
            media: "https://mitsubishi-electric.co.nz/heatpump/i/69227B/light-commercial-pka71-high-wall-heat-pump/image2.jpg"
          }
        ],
        name: "PKA Series",
        thumbnailImage: "https://mitsubishi-electric.co.nz/heatpump/i/69227B/light-commercial-pka71-high-wall-heat-pump/thumbnail.jpg",
        warrantyOptions: [
          {
            transferable: true,
            type: "Full Coverage",
            documents: [
              {
                document: "https://mitsubishi-electric.co.nz/heatpump/i/69227B/light-commercial-pka71-high-wall-heat-pump/warranty.pdf"
              }
            ],
            durationYears: 5
          }
        ],
        description: "The PKA Series delivers powerful, efficient climate control in a sleek, professional package. Perfect for technical spaces like server rooms and laboratories, it combines precise temperature control with advanced features that make maintenance simple. Its flexible installation options and choice of control systems let you customize the perfect solution for your space. With energy-efficient operation and optional hospital-grade air filtration, it creates a comfortable, healthy environment while keeping running costs low."
      }
    },
    {
      name: "RapidHeat Series",
      modelId: MODEL_ID,
      data: {
        seriesCode: "RapidHeat",
        unitConfig: "Floor Mounted",
        smartFeatures: {
          energyTracking: true,
          voiceControl: true,
          appControl: true,
          homeAutomationIntegration: true
        },
        brand: "Mitsubishi",
        keyFeatures: [
          {
            heading: "New Zealand's Quietest Heat Pump",
            summary: "Enjoy peaceful comfort with whisper-quiet operation starting at just 18dBA. Perfect for bedrooms and living spaces, it's so quiet you'll forget it's there - even during those cold winter nights."
          },
          {
            heading: "Fast Comfort When You Need It",
            summary: "Feel the warmth twice as fast with RapidHeat technology. Smart sensors and advanced controls work together to heat your room quickly and efficiently, so you're comfortable from the moment you need it."
          },
          {
            heading: "Built-in Wi-Fi Control",
            summary: "Control your comfort from anywhere with seamless Wi-Fi connectivity. Hidden neatly inside the unit, this feature lets you adjust settings from your phone whether you're at work, in bed, or away from home."
          },
          {
            heading: "Stylish, Space-Saving Design",
            summary: "The sleek, modern design can be recessed into your wall, reducing its depth by 33% - from 215mm to just 145mm. Perfect for renovations or replacing old fireplaces, it saves space while looking great."
          },
          {
            heading: "Even Heat Distribution",
            summary: "Experience consistent comfort with Multi Vane Flow. Warm air flows both upward and downward, eliminating cold spots and drafts while letting you customize airflow to suit your preferences."
          },
          {
            heading: "Energy-Efficient Performance",
            summary: "Save on power bills with advanced technology that maximizes efficiency. Features like Econo Cool help you stay comfortable while using less energy, especially during summer months."
          },
          {
            heading: "Environmentally Friendly",
            summary: "Feel good about your choice with R32 refrigerant technology, which has just one-third the environmental impact of older systems. It's more efficient and better for the planet, without compromising on performance."
          }
        ],
        productMedia: [
          {
            media: "https://mitsubishi-electric.co.nz/heatpump/i/69390B/rapidheat-kw25-floor-console-with-built-in-wi-fi-control/image1.jpg"
          },
          {
            media: "https://mitsubishi-electric.co.nz/heatpump/i/69390B/rapidheat-kw25-floor-console-with-built-in-wi-fi-control/image2.jpg"
          }
        ],
        name: "RapidHeat Series",
        thumbnailImage: "https://mitsubishi-electric.co.nz/heatpump/i/69390B/rapidheat-kw25-floor-console-with-built-in-wi-fi-control/thumbnail.jpg",
        warrantyOptions: [
          {
            transferable: true,
            type: "Full Coverage",
            documents: [
              {
                document: "https://mitsubishi-electric.co.nz/heatpump/i/69390B/rapidheat-kw25-floor-console-with-built-in-wi-fi-control/warranty.pdf"
              }
            ],
            durationYears: 5
          }
        ],
        description: "The RapidHeat Series is the only slimline floor console in New Zealand offering patented RapidHeat Technology, delivering warmth twice as fast as conventional systems. Its whisper-quiet operation and built-in Wi-Fi control make it perfect for any room where both comfort and convenience matter. The sleek, space-saving design fits beautifully in modern homes, while advanced features ensure efficient, comfortable heating all year round. Whether you're renovating, replacing an old fireplace, or looking for the perfect heating solution, the RapidHeat Series combines style, performance, and efficiency in one elegant package."
      }
    },
    {
      name: "RapidHeat Hyper Core",
      modelId: MODEL_ID,
      data: {
        seriesCode: "RapidHeat",
        unitConfig: "Floor Mounted",
        smartFeatures: {
          energyTracking: true,
          voiceControl: true,
          appControl: true,
          homeAutomationIntegration: true
        },
        brand: "Mitsubishi",
        keyFeatures: [
          {
            heading: "Superior Cold Weather Performance",
            summary: "Unlike standard heat pumps that lose heating power in cold weather, HyperCore Technology maintains full heating capacity even when it's -15°C outside. Perfect for homes in colder regions, you'll stay warm no matter how cold it gets."
          },
          {
            heading: "Rapid Heating Technology",
            summary: "Feel the warmth faster with smart two-way heating. The system first sends warm air downward, then recirculates it for a second round of heating, warming your room up to twice as fast as conventional models - perfect for those chilly winter mornings."
          },
          {
            heading: "Space-Saving Design",
            summary: "The sleek, modern unit can be recessed into your wall, reducing its depth by 33% (from 215mm to 145mm). Ideal for renovations or replacing old fireplaces, it saves space while enhancing your room's appearance."
          },
          {
            heading: "Even Heat Distribution",
            summary: "Three specially designed vanes work together to spread warm air both up and down, eliminating cold spots and creating consistent comfort throughout your room. You can also customize the airflow to suit your preferences."
          },
          {
            heading: "Energy-Smart Operation",
            summary: "Save on power bills with next-generation R32 technology. This advanced system is more environmentally friendly and energy-efficient than older heat pumps, helping you stay comfortable while keeping running costs low."
          },
          {
            heading: "Healthier Air For Your Family",
            summary: "Dual filtration system keeps your air clean and fresh. The Air Purifying Filter removes bacteria and odors, while the Anti-Allergy Filter captures allergens and harmful bacteria, creating a healthier home environment."
          },
          {
            heading: "Smart Weekly Timer",
            summary: "Program up to four temperature settings for each day of the week. Wake up to a warm home, save energy while you're away, and always come back to perfect comfort - all automatically."
          },
          {
            heading: "Built-in Wi-Fi Control",
            summary: "Control your heat pump from anywhere using your smartphone. Running late? Coming home early? Adjust your heating on the go so you always arrive to the perfect temperature."
          }
        ],
        productMedia: [
          {
            media: "https://mitsubishi-electric.co.nz/heatpump/i/69394B/hypercore-kw50-floor-console-with-built-in-wi-fi-control/image1.jpg"
          },
          {
            media: "https://mitsubishi-electric.co.nz/heatpump/i/69394B/hypercore-kw50-floor-console-with-built-in-wi-fi-control/image2.jpg"
          }
        ],
        name: "RapidHeat Hyper Core",
        thumbnailImage: "https://mitsubishi-electric.co.nz/heatpump/i/69394B/hypercore-kw50-floor-console-with-built-in-wi-fi-control/thumbnail.jpg",
        warrantyOptions: [
          {
            transferable: true,
            type: "Full Coverage",
            documents: [
              {
                document: "https://mitsubishi-electric.co.nz/heatpump/i/69394B/hypercore-kw50-floor-console-with-built-in-wi-fi-control/warranty.pdf"
              }
            ],
            durationYears: 5
          }
        ],
        description: "The RapidHeat HyperCore is New Zealand's best performing heat pump in cold conditions, guaranteed to deliver full heating power even when temperatures drop to -15°C. Perfect for homes in colder regions, it combines HyperCore's superior cold-weather performance with rapid heating technology to ensure consistent warmth throughout winter. Its sleek design and smart features create the ideal balance of performance and style, while energy-efficient operation helps keep running costs down. Whether you live in a cold climate zone or simply want the most reliable heating solution available, the RapidHeat HyperCore delivers exceptional comfort when you need it most."
      }
    },
    {
      name: "Classic Cassette Series",
      modelId: MODEL_ID,
      data: {
        seriesCode: "Classic",
        unitConfig: "Cassette",
        smartFeatures: {
          energyTracking: true,
          voiceControl: true,
          appControl: true,
          homeAutomationIntegration: true
        },
        brand: "Mitsubishi",
        keyFeatures: [
          {
            heading: "Smart Room Sensing",
            summary: "The intelligent i-See Sensor constantly monitors your room's temperature and occupancy, automatically adjusting settings for optimal comfort. Eight sensors rotate a full 360° every 3 minutes, ensuring everyone in the room stays comfortable without wasting energy."
          },
          {
            heading: "Energy-Efficient Performance",
            summary: "Save on power bills with advanced R32 technology that's better for both your wallet and the environment. This next-generation system uses less energy while delivering superior comfort, helping reduce your carbon footprint."
          },
          {
            heading: "Discreet Ceiling Installation",
            summary: "Enjoy more usable space with this ceiling-mounted design. Only a stylish grille is visible, making it perfect for homes and offices where floor or wall space is precious. It's New Zealand's favorite ceiling cassette for good reason."
          },
          {
            heading: "Draft-Free Comfort",
            summary: "Experience even temperature throughout your room with advanced horizontal airflow. Six different air discharge angles ensure smooth, comfortable air distribution without uncomfortable drafts - perfect for open-plan spaces."
          },
          {
            heading: "Whisper-Quiet Operation",
            summary: "Starting from just 25dBA, these units are incredibly quiet. You'll feel the comfort without hearing it, making them ideal for bedrooms, living areas, and office spaces where peace and quiet matter."
          },
          {
            heading: "Easy-Clean Air Filtration",
            summary: "Breathe cleaner, fresher air with the built-in filtration system. The long-life filter removes dust and contaminants for up to 2,500 hours before needing simple maintenance - keeping your air pure with minimal effort."
          },
          {
            heading: "Smart Weekly Programming",
            summary: "The optional Deluxe PAR Controller lets you set up to 8 different temperature patterns each day. Save energy when rooms are empty and ensure perfect comfort when they're in use - all automatically."
          },
          {
            heading: "Optional Wi-Fi Control",
            summary: "Add Wi-Fi control to manage your comfort from anywhere using your smartphone or tablet. Adjust settings, monitor usage, and ensure your space is always at the perfect temperature, even when you're away."
          }
        ],
        productMedia: [
          {
            media: "https://mitsubishi-electric.co.nz/heatpump/i/69263B/classic-slz25-cassette-heat-pump/image1.jpg"
          },
          {
            media: "https://mitsubishi-electric.co.nz/heatpump/i/69263B/classic-slz25-cassette-heat-pump/image2.jpg"
          }
        ],
        name: "Classic Cassette Series",
        thumbnailImage: "https://mitsubishi-electric.co.nz/heatpump/i/69263B/classic-slz25-cassette-heat-pump/thumbnail.jpg",
        warrantyOptions: [
          {
            transferable: true,
            type: "Full Coverage",
            documents: [
              {
                document: "https://mitsubishi-electric.co.nz/heatpump/i/69263B/classic-slz25-cassette-heat-pump/warranty.pdf"
              }
            ],
            durationYears: 5
          }
        ],
        description: "The Classic Cassette Series combines elegant ceiling-mounted design with powerful, efficient performance. Its discreet installation saves valuable floor space while delivering consistent comfort throughout the room. With advanced features like the i-See Sensor and optional Wi-Fi control, it automatically adjusts to maintain perfect temperatures while minimizing energy use. Whether for homes or offices, this whisper-quiet system provides the ideal balance of comfort, efficiency, and sophisticated climate control."
      }
    },
    {
      name: "4-Way Large Cassette",
      modelId: MODEL_ID,
      data: {
        seriesCode: "4-Way",
        unitConfig: "High Wall Split System",
        smartFeatures: {
          energyTracking: true,
          voiceControl: true,
          appControl: true,
          homeAutomationIntegration: true
        },
        brand: "Mitsubishi",
        keyFeatures: [
          {
            heading: "Smart Temperature Sensing",
            summary: "The advanced 3D i-See Sensor constantly monitors your space, detecting both floor temperature and room occupancy. Eight sensors work together, scanning the entire room every 3 minutes to ensure everyone stays comfortable while saving energy when areas are empty."
          },
          {
            heading: "Energy-Efficient Cooling and Heating",
            summary: "Save on running costs with next-generation R32 technology. This environmentally friendly system uses 20% less refrigerant and delivers better efficiency than traditional units, helping reduce both your power bills and environmental impact."
          },
          {
            heading: "Perfect for Upgrades",
            summary: "Replacing an older system? The unique pipe reuse technology lets you keep existing pipework while upgrading to more efficient R32 technology - saving installation time and costs while maintaining full warranty coverage."
          },
          {
            heading: "Draft-Free Comfort",
            summary: "Experience consistent comfort with advanced horizontal airflow. The system prevents cold or hot air from blowing directly on people, eliminating uncomfortable drafts while maintaining even temperatures throughout the room."
          },
          {
            heading: "Enhanced Heat Distribution",
            summary: "The Wave Airflow mode ensures better heating performance by gently moving warm air throughout the space. Special vanes periodically adjust up and down, creating consistent temperatures from floor to ceiling."
          },
          {
            heading: "Wide-Angle Coverage",
            summary: "Enjoy even temperatures in every corner with wide-angle outlets that distribute air throughout the entire room. The improved design reduces both horizontal airflow and fan speed by 20%, creating more comfortable conditions for everyone."
          },
          {
            heading: "Easy Maintenance",
            summary: "Keep your system running at its best with the optional automatic grille lowering feature. The grille can stop at eight different heights, making filter maintenance simple and hassle-free."
          }
        ],
        productMedia: [
          {
            media: "https://mitsubishi-electric.co.nz/heatpump/i/69233B/pla-m71-suz-wired-4-way-large-cassette/image1.jpg"
          },
          {
            media: "https://mitsubishi-electric.co.nz/heatpump/i/69233B/pla-m71-suz-wired-4-way-large-cassette/image2.jpg"
          }
        ],
        name: "4-Way Large Cassette",
        thumbnailImage: "https://mitsubishi-electric.co.nz/heatpump/i/69233B/pla-m71-suz-wired-4-way-large-cassette/thumbnail.jpg",
        warrantyOptions: [
          {
            transferable: true,
            type: "Full Coverage",
            documents: [
              {
                document: "https://mitsubishi-electric.co.nz/heatpump/i/69233B/pla-m71-suz-wired-4-way-large-cassette/warranty.pdf"
              }
            ],
            durationYears: 5
          }
        ],
        description: "The 4-Way Large Cassette combines powerful performance with intelligent comfort features, making it perfect for larger spaces. Its advanced airflow system ensures even temperatures throughout the room, while smart sensors automatically adjust settings to maintain comfort while saving energy. The sleek ceiling-mounted design saves valuable floor space, and optional features like automatic grille lowering make maintenance simple. Whether for commercial spaces or large residential areas, this system delivers efficient, comfortable climate control with sophisticated style."
      }
    },
    {
      name: "SlimFit Series",
      modelId: MODEL_ID,
      data: {
        seriesCode: "SlimFit",
        unitConfig: "Cassette",
        smartFeatures: {
          energyTracking: true,
          voiceControl: true,
          appControl: true,
          homeAutomationIntegration: true
        },
        brand: "Mitsubishi",
        keyFeatures: [
          {
            heading: "Auto Vane Control",
            summary: "Outlet vanes can be moved left and right when in Econo Cool mode, and up and down, using the remote controller; elimating draughts and enhancing room comfort."
          },
          {
            heading: "One-way Airflow",
            summary: "Ideal for rooms where one-way air distribution is required, and a solution for spaces where lighting fixtures are installed in the centre of a room, one-way airflow provides a comofrtable environment with no draughts."
          },
          {
            heading: "Compact Design",
            summary: "Our ceiling cassettes are New Zealand's favourite. With the lightweight unit sitting in your ceiling space, only the grille is visible providing easy, discreet installation into your home or office."
          },
          {
            heading: "Horizontal Airflow",
            summary: "Advanced horizontal airflow eliminates uncomfortable draughts and improves airflow control. Six different discharge angles provide a lateral airflow advantage; ensuring air is evenly distributed across your entire room."
          },
          {
            heading: "Quiet Operation",
            summary: "Starting from a hushed 26dBA, our MLZ Cassette Series is the perfect solution for quiet comfort; allowing you to feel the warmth, not hear it."
          },
          {
            heading: "Air Purifying Filter",
            summary: "This built-in filter removes dust and other particles, keeping the air clean all the time. Maintenance is as simple as vacuuming."
          }
        ],
        productMedia: [
          {
            media: "https://mitsubishi-electric.co.nz/heatpump/i/65300B/slimfit-mlz-25-cassette-heat-pump/image1.jpg"
          },
          {
            media: "https://mitsubishi-electric.co.nz/heatpump/i/65300B/slimfit-mlz-25-cassette-heat-pump/image2.jpg"
          }
        ],
        name: "SlimFit Series",
        thumbnailImage: "https://mitsubishi-electric.co.nz/heatpump/i/65300B/slimfit-mlz-25-cassette-heat-pump/thumbnail.jpg",
        warrantyOptions: [
          {
            transferable: true,
            type: "Full Coverage",
            documents: [
              {
                document: "https://mitsubishi-electric.co.nz/heatpump/i/65300B/slimfit-mlz-25-cassette-heat-pump/warranty.pdf"
              }
            ],
            durationYears: 5
          }
        ],
        description: "The SlimFit MLZ Series with its streamlined design, airflow control features, and quiet operation from just 26dBA, is ideal for small installation spaces where one-way air distribution is needed."
      }
    },
    {
      name: "Ceiling Suspended Series",
      modelId: MODEL_ID,
      data: {
        seriesCode: "Ceiling",
        unitConfig: "Ceiling Suspended",
        smartFeatures: {
          energyTracking: true,
          voiceControl: true,
          appControl: true,
          homeAutomationIntegration: true
        },
        brand: "Mitsubishi",
        keyFeatures: [
          {
            heading: "Stylish Design",
            summary: "Sharp, clean lines make this unit blend in more easily with your ceiling, providing low-profile heating or cooling."
          },
          {
            heading: "Next-Generation R32 Technology",
            summary: "R32 is a refrigerant with just one-third the global warming potential of R410A and has zero ozone depletion potential. R32 offers increased energy efficiency, and is said to be the next generation of refrigerants."
          },
          {
            heading: "Automatic Air Speed Adjustment",
            summary: "In addition to the conventional 4-speed setting, our suspended units are now equipped with an automatic air-speed adjustment mode. This setting automatically adjusts the air speed to match the room environment. At the start of heating or cooling operation, the airflow is set to high-speed to quickly heat or cool the room. When the room temperature reaches your desired setting, the airflow speed is decreased automatically for stable comfortable heating or cooling operation."
          },
          {
            heading: "Fresh Air Intake Option",
            summary: "Units are equipped with an opening that enables the induction of fresh outside air."
          },
          {
            heading: "Deluxe PAR Weekly Controller",
            summary: "This attractive full dot liquid crystal display incorporates a large backlit screen and simple menus for easy operation. You can set up to 8 temperature and airflow patterns per day for seven days, allowing you to reduce your energy consumption when needed, saving you both time and money. Perfect for the busy home, workplace or retail store."
          },
          {
            heading: "High and Low Ceiling Modes",
            summary: "Units are equipped with high and low ceiling operation modes that make it possible to switch the airflow volume to match room height. The ability to choose the optimum airflow volume makes it possible to optimise the breezy sensation felt throughout the room."
          }
        ],
        productMedia: [
          {
            media: "https://mitsubishi-electric.co.nz/heatpump/i/69276B/suspended-pca50-heat-pump/image1.jpg"
          },
          {
            media: "https://mitsubishi-electric.co.nz/heatpump/i/69276B/suspended-pca50-heat-pump/image2.jpg"
          }
        ],
        name: "Ceiling Suspended Series",
        thumbnailImage: "https://mitsubishi-electric.co.nz/heatpump/i/69276B/suspended-pca50-heat-pump/thumbnail.jpg",
        warrantyOptions: [
          {
            transferable: true,
            type: "Full Coverage",
            documents: [
              {
                document: "https://mitsubishi-electric.co.nz/heatpump/i/69276B/suspended-pca50-heat-pump/warranty.pdf"
              }
            ],
            durationYears: 5
          }
        ],
        description: "The SlimFit MLZ Series with its streamlined design, airflow control features, and quiet operation from just 26dBA, is ideal for small installation spaces where one-way air distribution is needed."
      }
    },
    {
      name: "Kitchen Suspended Series",
      modelId: MODEL_ID,
      data: {
        seriesCode: "Kitchen",
        unitConfig: "Ceiling Suspended",
        smartFeatures: {
          energyTracking: true,
          voiceControl: true,
          appControl: true,
          homeAutomationIntegration: true
        },
        brand: "Mitsubishi",
        keyFeatures: [
          {
            heading: "Built for Professional Kitchens",
            summary: "Specially designed with a durable stainless steel casing that resists oil, grease, and kitchen grime. Easy to clean and maintain, it stays looking professional even in the busiest commercial kitchens."
          },
          {
            heading: "Superior Oil Filtration",
            summary: "The heavy-duty oil mist filter is 50% more effective than standard filters at capturing kitchen oils and smoke. This disposable filter system makes maintenance simple while protecting your investment and keeping your kitchen air cleaner."
          },
          {
            heading: "Simple Cleaning Access",
            summary: "Designed with busy kitchens in mind, the fan casing comes apart easily for thorough cleaning. The quick-release drain pan makes routine maintenance straightforward, saving time and effort."
          },
          {
            heading: "Fresh Air Integration",
            summary: "Improve kitchen ventilation with the optional fresh air intake. This feature helps maintain better air quality by bringing in fresh outside air, creating a more comfortable working environment for kitchen staff."
          },
          {
            heading: "Energy-Efficient Operation",
            summary: "Save on running costs with advanced R32 technology. This next-generation system delivers efficient cooling while using less energy than traditional units - perfect for kitchens that operate long hours."
          },
          {
            heading: "Smart Temperature Control",
            summary: "The Deluxe PAR Controller features a large, easy-to-read display and simple controls. Set up to 8 different temperature patterns each day to match your kitchen's busy periods while saving energy during quieter times."
          }
        ],
        productMedia: [
          {
            media: "https://mitsubishi-electric.co.nz/heatpump/i/69480B/kitchen-suspended-pca-m71ha2-stainless-steel-heat-pump/image1.jpg"
          },
          {
            media: "https://mitsubishi-electric.co.nz/heatpump/i/69480B/kitchen-suspended-pca-m71ha2-stainless-steel-heat-pump/image2.jpg"
          }
        ],
        name: "Kitchen Suspended Series",
        thumbnailImage: "https://mitsubishi-electric.co.nz/heatpump/i/69480B/kitchen-suspended-pca-m71ha2-stainless-steel-heat-pump/thumbnail.jpg",
        warrantyOptions: [
          {
            transferable: true,
            type: "Full Coverage",
            documents: [
              {
                document: "https://mitsubishi-electric.co.nz/heatpump/i/69480B/kitchen-suspended-pca-m71ha2-stainless-steel-heat-pump/warranty.pdf"
              }
            ],
            durationYears: 5
          }
        ],
        description: "This stainless steel series is designed specifically for professional kitchens, combining durability with efficient performance. Its robust construction stands up to the demanding environment of commercial kitchens, while superior filtration handles oil and cooking residues with ease. Easy maintenance features and flexible programming options make it the perfect choice for restaurants, cafes, and commercial kitchens where reliable climate control is essential."
      }
    },
    {
      name: "Concealed SEZ Series",
      modelId: MODEL_ID,
      data: {
        seriesCode: "Concealed",
        unitConfig: "High Wall Split System",
        smartFeatures: {
          energyTracking: true,
          voiceControl: true,
          appControl: true,
          homeAutomationIntegration: true
        },
        brand: "Mitsubishi",
        keyFeatures: [
          {
            heading: "Completely Hidden Design",
            summary: "Perfect for homes with a modern, minimalist style. The unit installs completely out of sight above your ceiling, with only subtle air vents visible. Enjoy perfect comfort without compromising your room's aesthetics."
          },
          {
            heading: "Ultra-Quiet Operation",
            summary: "Experience whisper-quiet comfort with some of the lowest noise levels in its class. Perfect for bedrooms, living areas, and other spaces where peace and quiet matter most."
          },
          {
            heading: "Flexible Installation",
            summary: "The compact design fits easily into tight ceiling spaces, making it ideal for renovations or new builds. Multiple installation options ensure the perfect fit for your home's layout."
          },
          {
            heading: "Energy-Smart Performance",
            summary: "Save on power bills with advanced energy-efficient technology. The system automatically adjusts its output to match your needs, reducing energy waste while maintaining optimal comfort."
          },
          {
            heading: "Even Temperature Distribution",
            summary: "Enjoy consistent comfort throughout your space with advanced airflow design. The system delivers air evenly across the room, eliminating hot and cold spots for perfect comfort everywhere."
          },
          {
            heading: "Optional Wi-Fi Control",
            summary: "Add smart control capabilities to manage your comfort from anywhere. Adjust settings, monitor usage, and ensure your home is always at the perfect temperature using your smartphone."
          },
          {
            heading: "Easy Filter Maintenance",
            summary: "Keep your air clean with minimal effort. The long-life filter is easily accessible for quick cleaning, helping maintain optimal air quality and system efficiency."
          }
        ],
        productMedia: [
          {
            media: "https://mitsubishi-electric.co.nz/heatpump/i/69271B/concealed-sez-m35-heat-pump/image1.jpg"
          },
          {
            media: "https://mitsubishi-electric.co.nz/heatpump/i/69271B/concealed-sez-m35-heat-pump/image2.jpg"
          }
        ],
        name: "Concealed SEZ Series",
        thumbnailImage: "https://mitsubishi-electric.co.nz/heatpump/i/69271B/concealed-sez-m35-heat-pump/thumbnail.jpg",
        warrantyOptions: [
          {
            transferable: true,
            type: "Full Coverage",
            documents: [
              {
                document: "https://mitsubishi-electric.co.nz/heatpump/i/69271B/concealed-sez-m35-heat-pump/warranty.pdf"
              }
            ],
            durationYears: 5
          }
        ],
        description: "The Concealed SEZ Series offers the perfect solution for homeowners who want powerful climate control without visible equipment. These compact, whisper-quiet units fit neatly above your ceiling, delivering consistent comfort while maintaining your home's clean, modern aesthetic. With energy-efficient operation and smart control options, it provides reliable heating and cooling that's as discreet as it is effective. Whether you're building new or renovating, this system delivers perfect comfort without compromising your interior design."
      }
    },
    {
      name: "Ducted PEAD Series",
      modelId: MODEL_ID,
      data: {
        seriesCode: "PEAD",
        unitConfig: "Ducted",
        smartFeatures: {
          energyTracking: true,
          voiceControl: true,
          appControl: true,
          homeAutomationIntegration: true
        },
        brand: "Mitsubishi",
        keyFeatures: [
          {
            heading: "Discreet Whole-Home Comfort",
            summary: "With a slim 250mm height profile, this system hides away completely in your ceiling while heating or cooling your entire home. Only stylish vents are visible, maintaining your home's clean, modern look."
          },
          {
            heading: "Energy-Smart Technology",
            summary: "Save on power bills with advanced R32 technology that's better for both your wallet and the environment. This next-generation system delivers superior comfort while using less energy than traditional heating solutions."
          },
          {
            heading: "Flexible Airflow Options",
            summary: "Customize your comfort with adjustable airflow settings. Whether you have high ceilings or standard rooms, the system adapts to deliver perfect temperature control throughout your space."
          },
          {
            heading: "Smart Weekly Programming",
            summary: "The Deluxe PAR Controller makes it easy to set your perfect schedule. Program up to 8 temperature changes each day to match your lifestyle - wake up warm, save energy while you're away, and come home to comfort."
          },
          {
            heading: "Optional Zone Control",
            summary: "Control up to 8 different zones independently with the optional Zone Controller. Heat or cool only the rooms you're using, saving energy while ensuring everyone gets their perfect temperature."
          },
          {
            heading: "Advanced Air Filtration",
            summary: "Breathe healthier air with the optional Plasma Quad Connect. This hospital-grade filtration system removes dust, allergens, and other particles, creating cleaner, fresher air throughout your home."
          },
          {
            heading: "Whisper-Quiet Operation",
            summary: "Enjoy peaceful comfort with ultra-quiet operation. The system works silently in the background, so you'll feel the perfect temperature without hearing it."
          }
        ],
        productMedia: [
          {
            media: "https://mitsubishi-electric.co.nz/heatpump/i/69255B/ducted-pead-50-heat-pump/image1.jpg"
          },
          {
            media: "https://mitsubishi-electric.co.nz/heatpump/i/69255B/ducted-pead-50-heat-pump/image2.jpg"
          }
        ],
        name: "Ducted PEAD Series",
        thumbnailImage: "https://mitsubishi-electric.co.nz/heatpump/i/69255B/ducted-pead-50-heat-pump/thumbnail.jpg",
        warrantyOptions: [
          {
            transferable: true,
            type: "Full Coverage",
            documents: [
              {
                document: "https://mitsubishi-electric.co.nz/heatpump/i/69255B/ducted-pead-50-heat-pump/warranty.pdf"
              }
            ],
            durationYears: 5
          }
        ],
        description: "The Ducted PEAD Series transforms how you heat and cool your home, providing whole-house comfort that's completely hidden from view. Perfect for new homes or renovations, it delivers consistent temperatures throughout every room while keeping energy costs down. The optional zone control lets you customize comfort for different areas, while advanced filtration ensures clean, healthy air for your family. With its whisper-quiet operation and smart control options, it's the ideal solution for homeowners who want efficient, unobtrusive climate control."
      }
    },
    {
      name: "Ducted PEA Series",
      modelId: MODEL_ID,
      data: {
        seriesCode: "PEA",
        unitConfig: "Ducted",
        smartFeatures: {
          energyTracking: true,
          voiceControl: true,
          appControl: true,
          homeAutomationIntegration: true
        },
        brand: "Mitsubishi",
        keyFeatures: [
          {
            heading: "Unobtrusive Whole-Home Comfort",
            summary: "Experience complete climate control that's hidden from view. Designed specifically for ceiling installation, this system delivers powerful heating and cooling throughout your home while maintaining your interior's clean look - you'll only see stylish air vents."
          },
          {
            heading: "Energy-Smart Performance",
            summary: "Save on power bills with next-generation R32 technology. This advanced system is more environmentally friendly and energy-efficient than traditional units, helping you stay comfortable while keeping running costs low."
          },
          {
            heading: "Flexible Installation",
            summary: "Adapt the system perfectly to your home's layout. The versatile design allows for customized placement of air vents, ensuring optimal airflow and comfort in every room, regardless of your floor plan."
          },
          {
            heading: "Perfect Air Distribution",
            summary: "Enjoy consistent temperatures throughout your home. The high-pressure design ensures even airflow to every room, eliminating hot and cold spots while maintaining your ideal comfort level everywhere."
          },
          {
            heading: "Smart Weekly Programming",
            summary: "The Deluxe PAR Controller features an easy-to-read display and simple menus. Set up to 8 temperature patterns each day to match your lifestyle - save energy when you're away and ensure comfort when you're home."
          },
          {
            heading: "Advanced Zone Control",
            summary: "Transform your comfort with optional zone control. Manage up to 8 different areas independently, heat or cool only the rooms you're using, and let everyone choose their perfect temperature - all while saving energy."
          }
        ],
        productMedia: [
          {
            media: "https://mitsubishi-electric.co.nz/heatpump/i/69224B/ducted-pea100-heat-pump/image1.jpg"
          },
          {
            media: "https://mitsubishi-electric.co.nz/heatpump/i/69224B/ducted-pea100-heat-pump/image2.jpg"
          }
        ],
        name: "Ducted PEA Series",
        thumbnailImage: "https://mitsubishi-electric.co.nz/heatpump/i/69224B/ducted-pea100-heat-pump/thumbnail.jpg",
        warrantyOptions: [
          {
            transferable: true,
            type: "Full Coverage",
            documents: [
              {
                document: "https://mitsubishi-electric.co.nz/heatpump/i/69224B/ducted-pea100-heat-pump/warranty.pdf"
              }
            ],
            durationYears: 5
          }
        ],
        description: "The PEA Series delivers superior whole-home comfort with its powerful yet discreet ducted system. Perfect for larger homes and spaces, it combines high-performance heating and cooling with energy-efficient operation. The system's flexible design allows for customized installation, ensuring perfect comfort in every room while maintaining your home's aesthetic appeal. With smart controls and optional zoning, it offers the ideal balance of comfort, efficiency, and sophisticated climate control."
      }
    },
    {
      name: "PEA Splitable Series",
      modelId: MODEL_ID,
      data: {
        seriesCode: "PEA-Split",
        unitConfig: "Ducted",
        smartFeatures: {
          energyTracking: true,
          voiceControl: true,
          appControl: true,
          homeAutomationIntegration: true
        },
        brand: "Mitsubishi",
        keyFeatures: [
          {
            heading: "Hidden Whole-Home Comfort",
            summary: "Enjoy complete climate control that's out of sight. This ducted system fits neatly in your ceiling space, with only stylish vents visible. Perfect for homes where you want powerful heating and cooling without impacting your interior design."
          },
          {
            heading: "Easy Installation Design",
            summary: "The unique two-piece design makes installation simpler, especially in existing homes. The system can be easily transported and assembled in tight roof spaces, making it ideal for renovations and upgrades."
          },
          {
            heading: "Simple Maintenance Access",
            summary: "Keep your system running smoothly with easy maintenance access from multiple points. Whether from above or below, service technicians can easily reach all components, ensuring your system stays in top condition."
          },
          {
            heading: "Perfect for Tight Spaces",
            summary: "The innovative split design allows installation in homes with limited roof access. It fits perfectly between roof trusses, making it an ideal solution where traditional ducted systems might not work."
          },
          {
            heading: "Energy-Efficient Technology",
            summary: "Save on running costs with advanced R32 technology. This environmentally friendly system delivers efficient heating and cooling while reducing both your power bills and environmental impact."
          },
          {
            heading: "Flexible Installation Options",
            summary: "The two-piece design opens up more installation possibilities in your home. Whether you're building new or renovating, this system can be adapted to work with your home's unique layout."
          }
        ],
        productMedia: [
          {
            media: "https://mitsubishi-electric.co.nz/heatpump/i/69378B/pea-m100haa-deluxe-splittable-ducted-system/image1.jpg"
          },
          {
            media: "https://mitsubishi-electric.co.nz/heatpump/i/69378B/pea-m100haa-deluxe-splittable-ducted-system/image2.jpg"
          }
        ],
        name: "PEA Splitable Series",
        thumbnailImage: "https://mitsubishi-electric.co.nz/heatpump/i/69378B/pea-m100haa-deluxe-splittable-ducted-system/thumbnail.jpg",
        warrantyOptions: [
          {
            transferable: true,
            type: "Full Coverage",
            documents: [
              {
                document: "https://mitsubishi-electric.co.nz/heatpump/i/69378B/pea-m100haa-deluxe-splittable-ducted-system/warranty.pdf"
              }
            ],
            durationYears: 5
          }
        ],
        description: "The PEA Splittable Series brings innovative design to whole-home comfort, making it perfect for both new homes and renovations. Its unique two-piece construction allows for easy installation in spaces where traditional ducted systems might not fit. The system delivers powerful, efficient climate control while remaining completely hidden from view, with only subtle vents visible. Whether you're upgrading an existing system or planning a new installation, this versatile solution offers the perfect balance of performance, efficiency, and installation flexibility."
      }
    }
  ];